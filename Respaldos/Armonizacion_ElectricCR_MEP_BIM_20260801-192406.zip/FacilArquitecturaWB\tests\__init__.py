"""Tests for FacilArquitecturaWB."""
