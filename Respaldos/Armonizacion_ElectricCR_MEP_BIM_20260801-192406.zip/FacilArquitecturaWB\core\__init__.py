"""Core helpers for FacilArquitecturaWB."""

