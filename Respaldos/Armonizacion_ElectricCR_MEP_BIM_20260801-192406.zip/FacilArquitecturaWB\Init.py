"""FacilArquitecturaWB bootstrap.

Descripcion: arranque minimo del workbench Facil Arquitectura.
Fecha: 2026-07-31
Version: 0.6.0
Instrucciones: no cargar logica pesada aqui; FreeCAD importa este modulo al descubrir el workbench.
"""

from . import InitGui  # noqa: F401
